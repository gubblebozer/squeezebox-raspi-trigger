# PowerCenter copyright (c) 2006-2009 by Peter Watkins (peterw@tux.org) 
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2, which should be included with this software.

package Plugins::PowerCenter::Controller;

use strict;
# at least Perl 5
use 5;
use JSON::XS::VersionOneAndTwo;
use vars qw($VERSION @ISA @EXPORT);
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw();
$VERSION = '0.01';

sub new {
	my $class = shift;
	my $self = {};
	if ( scalar(@_) > 0 ) {
		my $restoreInfo = shift;
		$self = decode_json($restoreInfo);
		$self->{devices} = [ ];
	} else {
		# defaults
		# look for binaries distributed with the PowerCenter plugin
		$self->{name} = 'Dummy base class';
		$self->{devices} = [ ];
	}
	bless $self;
	return $self;
}

# description of this controller hardware + software
sub getName {
	my $self = shift;
	return $self->{name};
}
	
# whether the class could be used on this OS, etc.
# E.G. HeyuX10 would return 0 on Win32
sub isValid {
	my $self = shift;
	return 0;
}

#return serialized string needed to reconstruct this object
sub getState {
	my $self = shift;
	my $i = $self;
	$i->{devices} = [ ];
	return encode_json($i);
}

sub supportedProtocols {
	my $self = shift;
	# returns array pointer of supported protocols 
	# E.G. ['X10','Insteon']
	return [ ];
}

sub statusAvailable {
	# whether this controller can get the status of devices
	return 0;
}

sub addDevice {
	my $self = shift;
	push @{$self->{devices}}, shift;
}

sub getDevices {
	my $self = shift;
	return $self->{devices};
}

sub lightDimValues {
	# array pointer of possible discrete brightness values
	# that can be exlicitly set 
	# E.G. [10,20,30,40,50,60,70,80,90,100]
	return [ ];
}

# deviceAction( $deviceObjRef, $actionName [, $coderef [, $coderefArgs] ])
sub deviceAction {
	my $self = shift;
	my $deviceObj = shift;
	my $actionName = shift;
	# take $actionName action on $deviceObj if supported by $deviceObj
	#
	# if $coderef defined, execute it once action is complete; pass
	# $coderefArgs to $coderef if defined. This allows the caller to
	# know when a command is done even if it was later in the queue
	# or required something like an async HTTP call to execute
	#
	# use Slim::Utils::Scheduler::add_task() 
	# add_task( @task)
	#
	#  Add a new task to the scheduler. Takes an array for task identifier.  First element is a 
	#   code reference to the sheduled subroutine.  Subsequent elements are the args required by 
	#    the newly scheduled task.
	#
}

sub getDeviceStatus {
	my $self = shift;
	my $deviceObj = shift;
	my $param = shift;
	# return status or undef
	if (! $self->statusAvailable() ) { return undef; }
}

sub configParameters {
	my $self = shift;
	# array of hashes of config params
	# used to construct web UI asking for details
	return [ ];
#	return [ 'port' => 
#			[ 'description' => string('POWERCENTER_SERIAL_PORT'),
#			  'input' => 'text',
#			  'default' => &getOSPort(), 
#			],
#	  'path' => 
#			[ 'description' => string('POWERCENTER_PATH_TO_BINARY'), 
#			  'input' => 'text',
#			  'default' => &findBundledBinary(), 
#			],
#	];
}

sub setConfigParameters {
	my $self = shift;
	# pass in hash of name -> value
	# returns array of error messages (empty array if all OK/accepted)
	return [ 'Error: setConfigParameters not implemented!' ];
}

sub getGlobalActions {
	my $self = shift;
	# if multiple controllers configured, only offer the 
	# venn intersection of their global actions?
	return [ ];
#	return [
#		{'allOn' => {
#			'label' => string('POWERCENTER_ALL_ON'),
#				}
#		},
#		{'allOff' => {
#			'label' => string('POWERCENTER_ALL_OFF'),
#				}
#		},
#		{'allLightsOn' => {
#			'label' => string('POWERCENTER_ALL_LIGHTS_ON'),
#				}
#		},
#		{'allLightsOff' => {
#			'label' => string('POWERCENTER_ALL_LIGHTS_OFF'),
#				}
#		},
#	];
}

# globalAction( $actionName [, $coderef [, $coderefArgs] ])
sub globalAction {
	my $self = shift;
	my $actionName = shift;
	# use Slim::Utils::Scheduler::add_task() if this requires 
	# add_task( @task)
	#
	#  Add a new task to the scheduler. Takes an array for task identifier.  First element is a 
	#   code reference to the sheduled subroutine.  Subsequent elements are the args required by 
	#    the newly scheduled task.
	#
	# several time-consuming steps
	return;
}

sub getDeviceActions {
	my $self = shift;
	# for per-device UI, loop through getDevices() and
	# offer all actions listed here that are supported by the device
	return [ ];
#	return [
#		{'on' => {
#			'label' => string('POWERCENTER_ON'),
#			'status' => 'power',
#			'value' => 1,
#				}
#		},
#		{'off' => {
#			'label' => string('POWERCENTER_OFF'),
#			'status' => 'power',
#			'value' => 0,
#				}
#		},
#		{'dim' => {
#			'label' => string('POWERCENTER_DIM'),
#				}
#		},
#		{'brighten' => {
#			'label' => string('POWERCENTER_BRIGHTEN'),
#				}
#		},
#		{'brightness10' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_10_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 5,
#			'valuemax' => 14,
#				}
#		},
#		{'brightness20' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_20_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 15,
#			'valuemax' => 24,
#				}
#		},
#		{'brightness30' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_30_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 25,
#			'valuemax' => 34,
#				}
#		},
#		{'brightness40' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_50_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 45,
#			'valuemax' => 54,
#				}
#		},
#		{'brightness50' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_50_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 45,
#			'valuemax' => 54,
#				}
#		},
#		{'brightness60' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_60_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 55,
#			'valuemax' => 64,
#				}
#		},
#		{'brightness70' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_70_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 65,
#			'valuemax' => 74,
#				}
#		},
#		{'brightness80' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_80_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 75,
#			'valuemax' => 84,
#				}
#		},
#		{'brightness90' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_90_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 85,
#			'valuemax' => 94,
#				}
#		},
#		{'brightness100' => {
#			'label' => string('POWERCENTER_BRIGHTEN_TO_100_PERCENT'),
#			'status' => 'brightness',
#			'valuemin' => 95,
#			'valuemax' => 100,
#				}
#		},
#	];
}

1;


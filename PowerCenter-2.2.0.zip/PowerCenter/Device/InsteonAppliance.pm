# PowerCenter copyright (c) 2006-2009 by Peter Watkins (peterw@tux.org) 
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2, which should be included with this software.

package Plugins::PowerCenter::Device::InsteonAppliance;

use base qw(Plugins::PowerCenter::Device);
use strict;
# at least Perl 5
use 5;
use JSON::XS::VersionOneAndTwo;
use vars qw($VERSION @ISA @EXPORT);
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw();
$VERSION = '0.01';

sub new {
	my @args = @_;
	my $class = shift;
	my $self = {};
	if ( (scalar(@args) > 1) && defined($args[1]) && ($args[1] ne '') ) {
		my $restoreInfo = shift @args;
		$self = decode_json($restoreInfo);
		$self->{status} = undef;
		$self->{statusTimestamp} = 0;
	} else {
		# defaults
		# look for binaries distributed with the PowerCenter plugin
		$self->{name} = 'Dummy base class for devices';
		$self->{status} = undef;
		$self->{statusTimestamp} = 0;
	}
	bless $self;
	return $self;
}

# description of this controller hardware + software
sub getName {
	my $self = shift;
	return $self->{name};
}
	
#return serialized string needed to reconstruct this object
sub getState {
	my $self = shift;
	my $i = $self;
	$i->{status} = [ ];
	return encode_json($i);
}

sub statusAvailable {
	# whether this controller can get the status of devices
	return 1;
}

sub lightDimValues {
	# array pointer of possible discrete brightness values
	# that can be exlicitly set 
	# E.G. [10,20,30,40,50,60,70,80,90,100]
	return [ ];
}

sub deviceAction {
	my $self = shift;
	my $deviceObj = shift;
	my $actionName = shift;
	# take $actionName action on $deviceObj if supported by $deviceObj
	# TODO: implement
}

sub getDeviceStatus {
	my $self = shift;
	my $deviceObj = shift;
	my $param = shift;
	# return status or undef; if it's been "too long" since
	# the last status update, this should probably return undef
	# and schedule a medium-low priority query
	if (! $self->statusAvailable() ) { return undef; }
}

sub configParameters {
	my $self = shift;
	# array of hashes of config params
	# used to construct web UI asking for details
	return [ 'code' => 
			[ 'description' => string('POWERCENTER_INSTEON_DEVICE_ID'),
			  'input' => 'text',
			  'default' => 'AABBCC', 
			],
#	# isLight -- indicate that an appliance module is actually controlling a lamp
	  'isLight' => 
			[ 'description' => string('POWERCENTER_IS_LIGHT'), 
			  'input' => 'choice',
			  'default' => 'NO', 
			  'choices' => [
						'YES' => string('YES'),
						'NO' => string('NO'),
					],
			],
	];
}

sub setConfigParameters {
	my $self = shift;
	# pass in hash of name -> value
	# returns array of error messages (empty array if all OK/accepted)
	# TODO: implement
	return [ 'Error: setConfigParameters not implemented!' ];
}

sub getDeviceActions {
	my $self = shift;
	# for per-device UI, loop through getDevices() and
	# offer all actions listed here that are supported by the device
	#return [ 'on', 'off', 'brighten', 'dim' ];	# X10 lamp
	#return [ 'on', 'off' ];			# X10 appliance
	#return [ 'on', 'brightness10', 'brightness20', 'brightness30',	'brightness40', 'brightness50', 'brightness60', 'brightness70', 'brightness80', 'brightness90,', 'brightness100', 'status' ]; # Insteon lamp
	return [ 'on', 'off', 'status' ];		# Insteon appliance
	#return [ ];
}

sub getProtocol {
	my $self = shift;
	# returns string describing supported protocol,
	# e.g 'X10'
	return 'Insteon';
}

sub getConfigParameter{
	my $self = shift;
	my $paramName = shift;
	# TODO: implement
	# return value
}


1;

__END__



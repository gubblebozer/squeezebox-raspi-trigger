# PowerCenter copyright (c) 2006-2009 by Peter Watkins (peterw@tux.org) 
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2, which should be included with this software.

package Plugins::PowerCenter::Controller::InsteonPLM;

use strict;
# at least Perl 5
use 5;
use JSON::XS::VersionOneAndTwo;
use File::Spec::Functions qw(:ALL);
use POSIX qw(sprintf);
use base qw (Plugins::PowerCenter::Controller);
use vars qw($VERSION @ISA @EXPORT);
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw();
$VERSION = '0.01';

# normal controller methods
sub new {
	my $self = {};
	my @args = @_;
	my $class = shift;
	my $log = shift;
	$log->info("making controller object");
	if ( (scalar(@args) > 2) && defined($args[2]) && ($args[2] ne '') ) {
		my $restoreInfo = shift;
		$log->info("creating controller from JSON data");
		$self = decode_json($restoreInfo);
		$self->{devices} = [ ];
		if (! defined($self->{binpath}) ) { $self->{binpath} = &findBinary(); }
	} else {
		# defaults
		$log->info("creating new controller object");
		$self->{devices} = [ ];
		$self->{valid} = 1;
		# look for binaries distributed with the PowerCenter plugin
		$self->{binpath} = &findBinary();
		$self->{serialport} = &findPort();
	}
	$self->{log} = $log;
	$self->{name} = 'Insteon Serial PLM';
	$self->{maxhops} = 3;
	$self->{timeout} = 1000;
	if ( $self->{binpath} eq '' ) { $self->{valid} = 0; }
	$self->{name} = 'Insteon serial PLM';
	bless $self;
	return $self;
}

# description of this controller hardware + software
sub getName {
	my $self = shift;
	return $self->{name};
}
	
# whether the class could be used on this OS, etc.
# E.G. HeyuX10 would return 0 on Win32
sub isValid {
	my $self = shift;
	return $self->{valid};
}

#return serialized string needed to reconstruct this object
sub getState {
	my $self = shift;
	my $i = $self;
	$i->{devices} = [ ];
	return encode_json($i);
}

sub supportedProtocols {
	my $self = shift;
	# returns array pointer of supported protocols 
	# E.G. ['X10','Insteon']
	return [ 'Insteon' ];
}

sub statusAvailable {
	# whether this controller can get the status of devices
	return 1;
}

sub addDevice {
	my $self = shift;
	push @{$self->{devices}}, shift;
}

sub getDevices {
	my $self = shift;
	return $self->{devices};
}

sub lightDimValues {
	# array pointer of possible discrete brightness values
	# that can be exlicitly set 
	return [10,20,30,40,50,60,70,80,90,100];
}

# deviceAction( $deviceObjRef, $actionName [, $coderef [, $coderefArgs [, $priority]] ])
# priority: default is 50. higher number = more important. in general, 
#  10 = background status check just because it's been a while
#  25 = background status check b/c the user is starting to enter our menus
#  50 = user asking for a command to be sent
#  90 = important task, e.g. turning off the coffee pot when SC7 shuts down
sub deviceAction {
	my $self = shift;
	my $deviceObj = shift;
	my $actionName = shift;
	my $coderef = shift;
	my $coderefArgs = shift;
	my $priority = shift;
	if (! defined($priority) ) { $priority = 50; }
	# take $actionName action on if supported by $deviceObj
	# TODO: how to avoid duplicate tasks? disallow adding a task with
	# priority < 50 if an identical task is already present?
	my $queueInfo = [$deviceObj, $actionName, $coderef, $coderefArgs, $priority];
	my $act = 1;
	if ( $priority < 50 ) {
		foreach my $t ( @{$self->{queue}} ) {
			# BUG: should ignore priority of $t
			if ($t == $queueInfo) {
				$self->{log}->debug("looks like we already have a matching task (but adding this task anyway)");
				#$act = 0;
			}
		}
	}
	if ( $act == 1 ) {
		push @{$self->{queue}}, $queueInfo;
		if ( scalar(@{$self->{queue}}) == 1 ) {
			Slim::Utils::Scheduler::add_task(\&deviceActionRunner,\$self) 
		}
	}
	#
	# if $coderef defined, execute it once action is complete; pass
	# $coderefArgs to $coderef if defined. This allows the caller to
	# know when a command is done even if it was later in the queue
	# or required something like an async HTTP call to execute
	# take $actionName action on if supported by $deviceObj
	push @{$self->{queue}}, [$deviceObj, $actionName, $coderef, $coderefArgs];
	if ( scalar(@{$self->{queue}}) == 1 ) {
		Slim::Utils::Scheduler::add_task(\&deviceActionRunner,\$self) 
	}
	#
	# if $coderef defined, execute it once action is complete; pass
	# $coderefArgs to $coderef if defined. This allows the caller to
	# know when a command is done even if it was later in the queue
	# or required something like an async HTTP call to execute
}

sub getDeviceStatus {
	my $self = shift;
	my $deviceObj = shift;
	my $param = shift;
	# return status or undef
	if (! $self->statusAvailable() ) { return undef; }
	# TODO: implement
	return $deviceObj->getStatus();
}

sub configParameters {
	my $self = shift;
	# array of hashes of config params
	# used to construct web UI asking for details
	return [ 'port' => 
			[ 'description' => string('POWERCENTER_SERIAL_PORT'),
			  'input' => 'text',
			  'default' => &getOSPort(), 
			],
	  'path' => 
			[ 'description' => string('POWERCENTER_PATH_TO_BINARY'), 
			  'input' => 'text',
			  'default' => &findBundledBinary(), 
			],
	];
}

sub setConfigParameters {
	my $self = shift;
	# TODO
	# pass in hash of name -> value
	# returns array of error messages (empty array if all OK/accepted)
	return [ 'Error: setConfigParameters not implemented!' ];
}

sub getGlobalActions {
	my $self = shift;
	# if multiple controllers configured, only offer the 
	# venn intersection of their global actions?
	return [
		{'allOn' => {
			'label' => string('POWERCENTER_ALL_ON'),
				}
		},
		{'allOff' => {
			'label' => string('POWERCENTER_ALL_OFF'),
				}
		},
		{'allLightsOn' => {
			'label' => string('POWERCENTER_ALL_LIGHTS_ON'),
				}
		},
		{'allLightsOff' => {
			'label' => string('POWERCENTER_ALL_LIGHTS_OFF'),
				}
		},
	];
}

# globalAction( $actionName [, $coderef [, $coderefArgs] ])
sub globalAction {
	my $self = shift;
	my $actionName = shift;
	my $coderef = shift;
	my $coderefArgs = shift;
	# TODO
	# loop through all devices
	# 	add actions for each relevant device
	# add a status action for the last device we need to send a command to,
	# and pass $coderef & $coderefArgs to that action
	return;
}

sub getDeviceActions {
	my $self = shift;
	# for per-device UI, loop through getDevices() and
	# offer all actions listed here that are supported by the device
	return [
		{'on' => {
			'label' => string('POWERCENTER_ON'),
			'status' => 'power',
			'value' => 100,
				}
		},
		{'off' => {
			'label' => string('POWERCENTER_OFF'),
			'status' => 'power',
			'value' => 0,
				}
		},
		# DIM and BRIGHT require
		# first getting a device's status, 
		# then calculating the next step up or down,
		# and then sending a new command
#		{'dim' => {
#			'label' => string('POWERCENTER_DIM'),
#				}
#		},
#		{'brighten' => {
#			'label' => string('POWERCENTER_BRIGHTEN'),
#				}
#		},
		{'brightness10' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_10_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 5,
			'valuemax' => 14,
				}
		},
		{'brightness20' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_20_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 15,
			'valuemax' => 24,
				}
		},
		{'brightness30' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_30_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 25,
			'valuemax' => 34,
				}
		},
		{'brightness40' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_50_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 45,
			'valuemax' => 54,
				}
		},
		{'brightness50' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_50_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 45,
			'valuemax' => 54,
				}
		},
		{'brightness60' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_60_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 55,
			'valuemax' => 64,
				}
		},
		{'brightness70' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_70_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 65,
			'valuemax' => 74,
				}
		},
		{'brightness80' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_80_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 75,
			'valuemax' => 84,
				}
		},
		{'brightness90' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_90_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 85,
			'valuemax' => 94,
				}
		},
		{'brightness100' => {
			'label' => string('POWERCENTER_BRIGHTEN_TO_100_PERCENT'),
			'status' => 'brightness',
			'valuemin' => 95,
			'valuemax' => 100,
				}
		},
	];
}

# InsteonPLM routines:
# find plmsend
sub findBinary {
	my $pluginDir = Plugins::PowerCenter::Plugin::findOurDir();
	my $binname = 'plmsend';
	if ($^O =~ /Win32/) { $binname .= '.exe'; }
	my $plmsendpath = catdir($pluginDir,'bin',$binname);
	if ( -e $plmsendpath ) { return $plmsendpath; }
	return '';
}

# serial port?
sub findPort {
	for (my $i = 0; $i <10 ; ++$i ) {
		if ( -w "/dev/ttyS$i" ) {
			return &portToWindows("/dev/ttyS$i");
		}
	}
	# default
	return &portToWindows("/dev/ttyS0");
}

# windows names for serial ports
sub portToWindows($) {
	my $u = shift;
	if ( $u =~ m/S([0-9]*)$/ ) {
		return 'COM'.($1 - 1);
	}
	return $u;
}

# process our queue
# TODO: add optional priority. If passed, process *all* tasks with that priority or higher
# rather than just one task; this would allow processing any critical tasks before SC7 shutdown
sub deviceActionRunner {
	my $self = shift;
	if ( scalar(@{$self->{queue}}) < 1 ) { return 0; }
	my @queue = @{$self->{queue}};
	# TODO: loop through the queue looking for most important task
	my $do = shift @queue;
	my ($dev, $action, $coderef, $coderefArgs, $priority) = @{$do};
	# take $action on $dev->getCode()
	$self->executeCommand($dev,$action);
	# if $coderef defined, exec & pass $coderefArgs
	if ( defined($coderef) ) {
		if ( ref($coderef) ne 'CODE' ) {
			$self->{log}->error("action report coderef not valid!");
		} else {
			&$coderef($coderefArgs);
		}
	}
	$self->{queue} = \@queue;
	if ( scalar(@{$self->{queue}}) < 1 ) { return 0; }
	return 1;
}

# make the PLM command
sub executeCommand {
	my $self = shift;
	my $device = shift;
	my $action = shift;
	# code should be uppercase, alphanumeric only
	my $code = uc($device->getCode());
	$code =  s/[^0-9a-zA-Z]//g;
	my $hops = sprintf(".2X", $self->{maxhops});
	my $cmdlinearg;
	# TODO: is $action supported by $device ? if not, log error and return
	if ( ($action eq 'on') || ($action =~ m/brightness(\d*)$/) ) {
		my $level = 100;	# plain 'on' = 100% on
		if ($action =~ m/brightness(\d*)$/) { $level = $1; }
		my $bcode = sprintf("%.2X",int(255 * $level / 100));
		$cmdlinearg = "0262${code}${hops}11${level}";
	} elsif ( $action eq 'off' ) {
		$cmdlinearg = "0262${code}${hops}1300";
	} elsif ( $action eq 'status' ) {
		$cmdlinearg = "0262${code}${hops}1900";
	} else {
		$self->{log}->error("Unknown or unsupported action \"$action\" for device \"$code\"");
		return;
	}
	my $cmd = $self->{binpath} . ' -t ' . $self->{timeout} . ' -d ' . $self->{port} . ' ' . $cmdlinearg;
	open (RES, "$cmd |");
	my $res = <RES>;
	if ( $action eq 'status' ) {
		# parse status
		if ( $res =~ m/025.*(..)$/ ) {
			my $hexlevel = $1;
			my $level = int( hex($hexlevel) * 100 / 255 );
			$self->{log}->info("device $code is at level $level");
			$device->setStatus($level);
		} else {
			$self->{log}->info("error retrieving status for device $code");
			$device->setStatus(undef);
		}
	}
	return;
}

1;


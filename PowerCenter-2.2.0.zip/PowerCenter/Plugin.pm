# $Id: Plugin.pm,v 1.68 2009/09/30 03:26:10 peterw Exp peterw $

# SlimServer Copyright (c) 2001-2005 Sean Adams, Slim Devices Inc.
#
# PowerCenter Copyright (c) 2006-2008 Peter Watkins
#
# Insteon Device Manager support courtesy Greg Brown, 2007
#  http://gregbrown.net/squeeze/
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

package Plugins::PowerCenter::Plugin;

# -----------------  USER SETTINGS -------------------
#
# Use the web interface to set codes for individual players,
# as well as global settings ('br' location, serial port name, 
# resend count, list of other X-10 devices).
#
# This plugin depends on the PowerCenter command-line app for 
# control of X-10 devices, which can be found at 
# http://www.linuxha.com/bottlerocket/
# Compiled versions for Intel/x86/i386/ia32 Microsoft Windows
# or Linux are included now, as is the 'br' source code.
#
# For Insteon support, you will need the Insteon Device Manager
# software available at http://www.insteon.net/sdk/Files/dm/
#
# It is recommended that you verify the 'br' command works by 
# hand before trying this SlimServer plugin. If you have a TM751 
# transceiver module (http://www.x10.com/automation/x10_tm751.htm) 
# set for house code "A", you should be able to turn that module's 
# outlet on with a command like
#     br -x /dev/ttyS0 -c A -n 1
# and turn that module's outlet off with a command like
#     br -x /dev/ttyS0 -c A -f 1
#
# -----------------  USER SETTINGS -------------------

use vars qw($VERSION);
$VERSION = &rcsVersion();

use File::Spec::Functions qw(:ALL);
use File::Spec::Functions qw(updir);
#use Slim::Control::Command;
use Slim::Control::Request;
use Slim::Player::Client;
use Slim::Buttons::Common;
use Slim::Utils::Strings qw (string);
use Slim::Utils::Misc qw (msg);
use Slim::Hardware::IR;
use Time::HiRes;
use Slim::Utils::Prefs;


use Plugins::PowerCenter::Controller;
use Plugins::PowerCenter::Controller::InsteonPLM;
use Plugins::PowerCenter::Device;
use Plugins::PowerCenter::Device::InsteonAppliance;
use Plugins::PowerCenter::Device::InsteonLamp;

use Plugins::PowerCenter::Device;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.PowerCenter',
#	'defaultLevel' => 'WARN',
#	'defaultLevel' => 'DEBUG',
#	'description'  => getDisplayName(),
});

use vars qw($VERSION);
$VERSION = &rcsVersion();
	
my $prefs = preferences('plugin.PowerCenter');

my $minRepeatWait = 5 * $Slim::Hardware::IR::IRMINTIME;
 
sub rcsVersion() {
        my $rcsVersion = '$Revision: 1.68 $';
        $rcsVersion =~ s/^.*:\s*([0-9]{1}\S*)\s.*$/$1/;
        return $rcsVersion;
}

my %controllerTypes;
my %deviceTypes;

my %playerStatus;		# track the last X10 command per-player
my $pluginEnabled = 0;		# keep track of whether this plugin should be active
my $callbackSet = 0;		# keep track of whether we've set our hooks
my @otherDeviceCodes;		# Devicec codes for "others"
my @otherDeviceNames;		# names for "others"
my %allHouseCodes;		# all house code letters from "other" devices
my @otherLampDevices;		# "other" devices with "+" in their names that are treated as lamps
my %lastActionTime;		# track time of last action for this player
my %lastActionArgs;		# track last action for this player
my %powerToggle;		# track whether button means "on" or "off"
my $minCursorValue;		# $ALL_LIGHTS_POS if there are "other devices" configured, $THIS_DEVICE_POS otherwise
my $canMakeCoffee = 0;		# whether this version of SC7 supports the APIs needed for coffeepot use
my %coffeepotsInUse;
# do not change the following constants!
my $plc = '08 A1 D3';
my $heyuPort = undef;

my $THIS_DEVICE_POS = -1;
my $ALL_DEVICES_POS = -2;
my $ALL_LIGHTS_POS = -3;

my @commandQueue;

my $originalPowerCommand;
my $originalPlayCommand;
my $originalPlaylistCommand;

our %current = (); #Used for Insteon menu

sub getDisplayName {
	return 'PLUGIN_POWERCENTER';
}

sub enabled {
	if ( substr($::VERSION,0,3) gt '7.2' ) {
		$log->warn("This plugin has not been tested with SlimServer newer than 7.2.x\n");
	}
	# the new web config code does not work with SlimServer 6.3.x
	return ($::VERSION ge '7.0');
}

our %brMap = (
	'rew.repeat' => 'rew_repeat',
	'fwd.repeat' => 'fwd_repeat',
	'add.repeat' => 'add_repeat',
	'pause.repeat' => 'pause_repeat',
	'play.repeat' => 'play_repeat',
);

my @prefNames = ('code','brcommand','port','resend', 'others','dmhost');
sub migratePrefs {
	# do nothing if we've already migrated
	my $migrated = $prefs->get('migrated');
	if ( defined($migrated) && ($migrated eq '1') ) { return; }
	# is br-command still OK? (diff paths for SC7?)
	my $cmd =  $prefs->get('brcommand');
	if ( defined($cmd) && ($cmd ne '') && (! -f $cmd) ) {
		# look for 'br' again
		$prefs->set('brcommand', '');
		&initPrefs();
	}
	# don't do this again!
	$prefs->set('migrated','1');
}

sub addJiveMenu {
	# do nothing if no "other devices"
	if ( scalar(@otherDeviceCodes) < 1 ) { return; }
	my $typeString = join ', ', @typeArray;
	$typeString = string('PLUGIN_POWERCENTER');
	# first add our node
	my @nodeMenu = ({
		text           => $typeString,
		weight         => 5,
		id             => 'pluginPowerCenterMenu',
		#window         => { titleStyle => 'settings' },
		actions => {
			go => {
				player => 0,
				cmd      => [ 'brJiveDevices' ],
			}
		},
	});
	Slim::Control::Request::addDispatch(['brJiveDevices'],[1, 1, 0, \&brJiveDevices]);
	Slim::Control::Request::addDispatch(['brPerDeviceMenu', '_device'],[1, 1, 0, \&brPerDeviceMenu]);
	Slim::Control::Jive::registerPluginMenu(\@nodeMenu,'extras');
}

sub brJiveDevices {
	my $request = shift;
	my $client = $request->client();
	# build our per-device menu nodes
	my @menu;
	for (my $i = 0; $i < scalar(@otherDeviceCodes); ++$i ) {
		my $dev = $otherDeviceCodes[$i];
		my $devName = $otherDeviceNames[$i];
		$devName =~ s/\(\+\)//;
#print STDERR "PowerCenter adding menu node \"$devName\" for \"$dev\"\n";
		push @menu, {
			text    => $devName,
			id      => "pluginPowerCenterDevice-$dev",
			#window => { menuStyle => 'album' },		# device choice menu uses icons
			weight  => $i,
			#window         => { titleStyle => 'settings' },
			actions => {
				go => {
					player => 0,
					cmd      => [ 'brPerDeviceMenu', $dev ],
					params => {
						#menu => "nowhere",
						menu => "pluginPowerCenterDevice-$dev",
					},
				},
				add => {
					player => 0,
					cmd    => [ 'bottlerocket', $dev, 'MCOFF', sprintf(string('POWERCENTER_TURNING_OFF'),$devName)],
					params => {
						menu => 'nowhere',
					},
				},
				play => {
					player => 0,
					cmd    => [ 'bottlerocket', $dev, 'MCON', sprintf(string('POWERCENTER_TURNING_ON'),$devName) ],
					params => {
						menu => 'nowhere',
					},
				},
			},
		};
	}
	my $numitems = scalar(@menu);
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	$request->setStatusDone();
}

sub brPerDeviceMenu {
	my $request = shift;
	my $client = $request->client();
	my $device = $request->getParam('_device');
	# per-device menus
	my @menu;
	my %imageName = (
		'MCON' => 'power-on',
		'MCOFF' => 'power-off',
		'PLUGIN_POWERCENTER_BRIGHTEN' => 'brighten',
		'PLUGIN_POWERCENTER_DIM' => 'dim',
	);
	my %stringName = (
		'MCON' => 'POWERCENTER_TURNING_ON',
		'MCOFF' => 'POWERCENTER_TURNING_OFF',
		'PLUGIN_POWERCENTER_BRIGHTEN' => 'PLUGIN_POWERCENTER_BRIGHTENING',
		'PLUGIN_POWERCENTER_DIM' => 'PLUGIN_POWERCENTER_DIMMING',
	);
	DEV: for (my $i = 0; $i < scalar(@otherDeviceCodes); ++$i ) {
		my $dev = $otherDeviceCodes[$i];
		if ( $dev ne $device ) { next DEV; }
		my $devName = $otherDeviceNames[$i];
		$devName =~ s/\(\+\)//;
#print STDERR "PowerCenter adding menu item \"$devName\" for \"$dev\"\n";
		my $weight = 0;
		# all devices have On and Off
		my @choices = ( 'MCON', 'MCOFF' );
		# other choices depend on device
		if ( $dev =~ m/^[a-z][0-9]{1,2}$/i ) {
			# X-10
			push @choices, 'PLUGIN_POWERCENTER_BRIGHTEN', 'PLUGIN_POWERCENTER_DIM';
		} else {
			# Insteon
			push @choices, "10%", "20%", "30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%";
		}
		foreach my $choice ( @choices ) {
			my $textString = $choice;
			my $messageString = 'PLUGIN_POWERCENTER_DIM_TO';
			if ( defined($stringName{$choice}) ) {
				$messageString = $stringName{$choice};
			}
			if ( $choice !~ m/^[0-9]*\%$/ ) {
				$textString = string($choice);
			}
			my $imageFile = 'blank.gif';
			if ( defined($imageName{$choice}) ) {
				$imageFile = $imageName{$choice}.'.gif';
			}
#print STDERR "dev $dev choice $choice icon $imageFile\n";
			my $item = {
				text    => $textString,
				id      => "pluginPowerCenterDevice-$dev-$choice",
				#'icon-id' => 'plugins/PowerCenter/html/images/'.$imageFile,
				#window         => { titleStyle => 'settings' },
				weight  => $weight++,
				actions => {
					do => {
						player => 0,
						cmd    => [ 'bottlerocket', $dev, $choice, sprintf(string($messageString),$devName,$choice) ],
						params => {
							menu => 'nowhere',
						},
					},
				},
			};
			push @menu, $item;
		}
	}
	my $numitems = scalar(@menu);
	#$request->addResult("base", {window => { titleStyle => 'album' }});
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	$request->setStatusDone();
}

sub brTopMenu {

}

sub brCLI{
        my $request = shift;
	my $client = $request->client();
        # much of this from IR Blaster
        # Check this is the correct query
        if( $request->isNotCommand( [['bottlerocket']])) {
                $request->setStatusBadDispatch();
                return;
        }
        my $dev = $request->getParam( '_device');
        my $action = $request->getParam( '_action');
        my $message = $request->getParam( '_message');
#print STDERR "brCLI message: $message\n";
        if ( (!defined($dev)) || (!defined($action)) ) {
                $request->setStatusBadDispatch();
                return;
        }
	$client->showBriefly( { 'jive' => { 'text'    => [ $message ], } },{'duration' => 1, 'block' => 1, } );
	if ( $action =~ m/^MCO(N|FF)$/ ) {
		my $powerArg = '-n';
		if ( $action eq 'MCOFF' ) { $powerArg = '-f'; }
		# make a new command line array
		if ( &testPrefs ) {
			&sendX10Code($dev,$powerArg,undef,'CLI');
		}
	} elsif ( $action =~ m/^PLUGIN_POWERCENTER_(BRIGHTEN|DIM)/ ) {
		my $dimVal = 2;
		if ( $action eq 'PLUGIN_POWERCENTER_DIM' ) { $dimVal = -1;}
		if ( &testPrefs ) {
			&sendX10Code($dev,'-d',$dimVal.',','CLI');
		}
	} else {
		$action =~ s/[^0-9]//g;	# make $action a simple % number (0, 10, ... 100)
		# 0-100%
		&addToQueue('_INSTEON', 'SetOnLevelText=' . $dev . ',' . $action . "%25", 'CLI');
	}
	my @menu;
	my $item = {
		text    => string('BR_COMMAND_SENT'),
		id      => "pluginPowerCenterDevice-$dev-$choice-action",
		#window         => { titleStyle => 'settings' },
	};
	push @menu, $item;
	my $numitems = scalar(@menu);
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	$request->setStatusDone();
}

sub initPlugin {
	# migrate old global prefs
	&migratePrefs;
	# initialize default preferenes
	&initPrefs;
	# see if they're OK
	&testPrefs;
	if ( $callbackSet != 1 ) {
		if (!$::noweb) {
			require Plugins::PowerCenter::Settings;
			require Plugins::PowerCenter::PlayerSettings;
		}
		# set up for handling fwd/rew keys being held
		Slim::Buttons::Common::addMode( 'PLUGIN.PowerCenter', &getFunctions, \&setMode );
		Slim::Buttons::Home::addSubMenu('PLUGINS', 'PLUGIN_POWERCENTER',  { 'useMode'  => 'PLUGIN.PowerCenter', });
		Slim::Hardware::IR::addModeDefaultMapping('PLUGIN.PowerCenter',\%brMap);
		# load info about "other" X-10 devices
		&loadOtherArrays();
		# use the cleaner addDispatch technique
		$log->debug("register server.power change handler");
		preferences('server')->setChange(\&powerChange, 'power');
		#
		if ( substr($::VERSION,0,3) ge '7.2' ) {
			$log->debug("subscribing alarmPlay callback to \"alarm sound\" event\n");
			Slim::Control::Request::subscribe( \&alarmSoundHandler, [['alarm']],[['sound']]);
			$canMakeCoffee = 1;
		}
		if ($^O =~ /Win32/) {
			# Windows needs Win32-specific libs
			require Win32::Process;
			import Win32::Process;
			require Win32;
			import Win32;
		}
		$callbackSet = 1;
		if (!$::noweb) {
			# global settings module
			Plugins::PowerCenter::Settings->new;
			# per-player settings module
			Plugins::PowerCenter::PlayerSettings->new;
		}
		# CLI command
		Slim::Control::Request::addDispatch(['bottlerocket','_device','_action','_message'], [0, 0, 0, \&Plugins::PowerCenter::Plugin::brCLI]);
                # use Slim::Web::HTTP::protectCommand to protect against CSRF
                $log->debug("protecting 'bottlerocket' command against CSRF attacks\n");
		if ( substr($::VERSION,0,3) lt 7.4 ) {
                	Slim::Web::HTTP::protectCommand('bottlerocket');
		} else {
                	Slim::Web::HTTP::CSRF->protectCommand('bottlerocket');
		}
		# Jive menu
		&addJiveMenu();
		# load controller & device drivers
		&loadDrivers();
	}
	$pluginEnabled = 1;
}

sub shutdownPlugin {
	# try to turn pots off that are still on!
	# first, clear out our command queue (nothing else matters!)
	@commandQueue = ();
	# find device names for pots that still need to be turned off
	my @potsToTurnOff = ();
	foreach my $dev ( keys %coffeepotsInUse ) {
		if ( $coffeepotsInUse{$dev} > 0 ) {
			push @potsToTurnOff, $dev;
        		$log->warn("PowerCenter shutting down, will try to turn off coffeepot $dev first\n");
		}
	}
	# queue up two off commands per pot
	for (my $i = 0; $i < 2; ++$i) {
		foreach my $dev ( @potsToTurnOff ) {
			&sendX10Code($dev,'-f',undef,'POTSAFETY');
		}
	}
	# process the queue
	while ( &processCommandFromQueue() != 0 ) {
		# clear our queue before we relinquish control!
	}
        # we should not act
        $pluginEnabled = 0;
}

sub PowerCenter_playlistCommand {
        $log->debug("PowerCenter_playlistCommand running\n");
        my @args = @_;
        # call the original function
	$log->debug("calling original \"playlist\" command\n");
	my $rc = &$originalPlaylistCommand(@args);
        if ( $pluginEnabled == 1 ) {
		&sendNeededCommands();
        }
	return $rc;
}

sub PowerCenter_playCommand {
        $log->debug("PowerCenter_playCommand running\n");
        my @args = @_;
        # call the original function
	$log->debug("calling original \"play\" command\n");
	my $rc = &$originalPlayCommand(@args);
        if ( $pluginEnabled == 1 ) {
		&sendNeededCommands();
        }
	return $rc;
}

sub powerChange {
        if ( $pluginEnabled == 1 ) {
		&sendNeededCommands();
        }
}

sub getPlayerBaseName($) {
	my $player = shift;
	my $name = $player->name();
	# strip the "synced with" string if present (should be l10n-ready)
	my $syncedWithString = string('SYNCHRONIZED_WITH');
	$name =~ s: \(${syncedWithString}.*\)$::;
	return $name;
}

sub portTransform($) {
	my $port = shift;
	# windows needs to use /dev/ttyS0 type device names
	if ( $port =~ m|^COM(\d*)$| ) {
		my $which = $1;
		--$which;
		$port = "/dev/ttyS${which}";
	}
	return $port;
}

sub testPrefs {
	my $rc = 1;
	my $cmd = $prefs->get('brcommand');
	if ( (! -f $cmd) || (! -x $cmd) ) {
		$log->warn("bottlerocket command \"$cmd\" is not installed or not executable\n");
		$rc = 0;
	}
	my $port = &portTransform($prefs->get('port'));
	if ( ((! -e $port) || (! -w $port)) && ($^O =~ /linux/i) ) {
		$log->warn("bottlerocket port \"$port\" does not exist or is not usable\n");
		$rc = 0;
	}
	my $resend = $prefs->get('resend');
	if ( $resend !~ /^[0-9]*$/ ) {
		$log->warn("bottlerocket resend count \"$resend\" is not a number\n");
		$rc = 0;
	}
	return $rc;
}

sub initPrefs {
	my $cmd = $prefs->get('brcommand');
	if ( (! -f $cmd) || (! -x $cmd) ) {
		$log->warn("bottlerocket command \"$cmd\" is not installed or not executable\n");
		$rc = 0;
	}
	my $port = &portTransform($prefs->get('port'));
	if ( ((! -e $port) || (! -w $port)) && ($^O =~ /linux/i) ) {
		$log->warn("bottlerocket port \"$port\" does not exist or is not usable\n");
		$rc = 0;
	}
	my $cmd = $prefs->get('brcommand');
	if ( (!defined($cmd)) || ($cmd eq '') ) {
		# look for 'br'
		my $command = undef;
		my @paths = split(/\:/, (defined($ENV{PATH}) ? $ENV{PATH} : ""));
		for (my $i = 0; ($i < scalar(@paths)) && (!defined($command)); ++$i) {
			my $possible = "$paths[$i]/br";
			if ( (-f $possible) && (-x $possible) ) {
				$log->info("found br at $possible\r\n");
				$command = $possible;
			}
		}
		if (! defined($command) ) {
			# find our directory
			my $ourDir = &findOurDir();
			if ( defined($ourDir) && ($^O =~ /Win32/) ) {
				# use the bundled Cygwin EXE
				$command = catdir($ourDir,'bin','br.exe');
				$log->info("win32 $command\r\n");
			} elsif ( defined($ourDir) && ($^O =~ /linux/i) && ($Config::Config{'archname'} =~ m/^i[3456]86-/) ) {
				# use the bundled i386/elf executable
				$command = catdir($ourDir,'bin','br');
				$log->info("x86 linux: use $command\r\n");
				if ( ! -x $command ) {
					if (! chmod 0775, $command ) {
						# can't use this command!
						$log->warn("x86 linux: cannot change permissions to use $command\r\n");
						$command = '/usr/local/bin/br';
					}
				}
			} else {
				$log->warn("no br found, default to /usr/local\r\n");
				$command = '/usr/local/bin/br';
			}
		}
		$prefs->set('brcommand',$command);
	}
	my $port = $prefs->get('port');
	if (! defined($port) ) {
		my $portname = '/dev/firecracker';
		if ( (! -e $portname) && ($^O =~ /Win32/) ) {
			$portname = 'COM1';
		} elsif ( (! -e $portname) && (-e '/dev/ttyS0') ) {
			$portname = '/dev/ttyS0';
		}
		$prefs->set('port',$portname);
	}
	my $resend = $prefs->get('resend');
	if (! defined($resend) ) {
		$prefs->set('resend',3);
	}
	my $others = $prefs->get('others');
	if (! defined($others) ) {
		$prefs->set('others','');
	}
	my $dmhost = $prefs->get('dmhost');
	if (! defined($dmhost) ) {
		$prefs->set('dmhost','localhost:9020');
	}
}

sub findOurDir() {
	my @dirs;
	if ( substr($::VERSION,0,3) lt 7.4 ) {
		@dirs = Slim::Utils::PluginManager::pluginRootDirs();
	} else {
		@dirs = Slim::Utils::PluginManager::dirsFor();
	}
	foreach my $dir ( @dirs ) {
		if ( $dir =~ m|\bPowerCenter$| ) {
			return $dir;
		}
	}
	return undef;
}

sub loadDrivers() {
	# controllers
	# insteonPLM
	my $t1 = "Plugins::PowerCenter::Controller::InsteonPLM";
	my $p1 = $prefs->get($t1);
	my $c1 = ${t1}->new($log,$p1);
	my $n1 = $c1->getName();
	$controllers{$n1} = $c1;
#print STDERR "$n1 is a ".ref($c1)."\n";
}

sub findModules($) {
	my $topdir = shift;
	my @res = ();
	my @next = ();
	if (opendir(D,$topdir)) {
		while (my $item = readdir(D) ) {
			my $full = catdir($topdir,$item);
			if ( (-f $full) && ($item =~ m/\.pm$/) ) {
				push @res, $full;
			} elsif ( $item =~ m/^\.\.?$/ ) {
				# self or parent, ignore
			} elsif ( -d $full ) {
				push @next, $full;
			}
		}
		closedir(D);
	}
	foreach $d ( @next ) {
		push @res, &findModules($d);
	}
	return @res;
}

sub sendNeededCommands() {
	# from RPC.pm:
	# get a list of all the players
        my @players = Slim::Player::Client::clients();
	my %actedOn;
	# consider them one by one
        for my $player (@players) {
		# get the player's name and power status (power status
		# as of SlimServer 6.2.2 is the power status *after*
		# completing the current command, i.e. "off" means we
		# should turn the amplifier off)
		my $name = &getPlayerBaseName($player);
		my $id = $player->id();
		# only really look at players listed as having X10 numbers
		my $x10Code = $prefs->client($player)->get('code');
		# the following validation shouldn't be needed, but we do it anyway to help ensure good system() calls
		if ( defined($x10Code) && ($x10Code =~ m/^([a-z][0-9]{1,2}|[a-z0-9\.]{1,})$/i) ) { 
			my $power = $player->power();
			# if we don't remember the player's status or it has changed, we need to act
			if ( (!defined($playerStatus{$id})) || ($playerStatus{$id} != $power) ) {
				# decide to turn ON or OFF
				my $powerArg = '-n';
				my $act = 1;
				if ( $power == 0 ) { 
					# multizone support
					$act = 0;
					if ( &noOtherPlayersOn($id,$x10Code) ) {
						$powerArg = '-f'; 
						$act = 1;
					}
				}
				# make a new command line array
				if ($act && (!defined($actedOn{$x10Code})) ) {
					if ( &testPrefs ) {
						&sendX10Code($x10Code,$powerArg,undef,$id);
					}
					$actedOn{$x10Code} = 1;
				}
				# note the status so we won't run the command again when another player's power status changes
				$playerStatus{$id} = $power;
			} else {
				$log->debug("player $name (ID $id) is already at power $power\n");
			}
		}
	}
}

sub noOtherPlayersOn {
	my ($whichId,$whichX10Code) = @_;
        for my $player (Slim::Player::Client::clients()) {
		my $id = $player->id();
		if ( $id ne $whichId ) {
			my $x10Code = $prefs->client($player)->get('code');
			if ( defined($x10Code) && ($x10Code eq $whichX10Code) ) { 
				if ( $player->power() ) {
					# wait for this other player
					$log->info("PowerCenter: not shutting off $x10Code because ".$player->name()."is still on\n");
					return 0;
				}
			}
		}
	}
	# no other players with that code still on
	return 1;
}


sub _PowerCenterCallback {
	# do nothing if not enabled
	$log->debug("_PowerCenterCallback running\n");
	if ( $pluginEnabled != 1 ) { return; }
	&sendNeededCommands();
}

sub deviceAction($$$$$) {
	my ($pos,$client,$powerArg,$powerName,$dimArg,$line) = @_;
	my $id = $client->id();
	if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) {
		$powerArg = '-f';
		$powerName = 'OFF';
		$powerToggle{$id} = 0;
	}
	if ( scalar(@otherDeviceCodes) > $pos ) {
		&sendCode($client,$powerArg,$powerName,$dimArg,$pos,$line);
	}
}

sub sendCode($$$$$) {
	my ($client,$powerArg,$powerName,$dimArg,$pos,$line2) = @_;
	my $id = $client->id();
	my $argString = join("\t",$powerArg,$id,$dimArg,$pos,$line2);
	my $now  = Time::HiRes::time();
	if ( (!defined($dimArg)) && (!defined($line2)) && defined($lastActionTime{$id}) ) {
		my $elapsed = $now - $lastActionTime{$id};
		#$log->debug("last $lastActionTime{$id} now is $now minwait is $minRepeatWait elapsed is $elapsed\n");
		if ( ($argString eq $lastActionArgs{$id}) &&
#||
#			($lastActionArgs{$id} =~ m/^\-n/ && ($powerArg eq '-f') ) ) && 
			($elapsed < $minRepeatWait) ) {
			# too soon to act again
			$log->debug("too soon to send another code for $id (argString \"$argString\")\n");
			$client->bumpLeft($client);
			$client->lines(\&lines);
			$client->update();
			return;
		}
	}
	if (! defined($pos) ) {
		$pos = &advanceCursor($client,0);
		if ( ($pos == $ALL_DEVICES_POS) && (!defined($dimArg)) ) {
			&sendAll($client);
			return;
		}
		if ( ($pos == $ALL_LIGHTS_POS) && (!defined($dimArg)) ) {
			&allLights($client,lc($action));
			return;
		}
		if ( ($pos < $minCursorPos) || ($pos == $THIS_DEVICE_POS) ) {
			$client->bumpRight($client);
			$client->lines(\&lines);
			$client->update();
			return;
		}
	}
	if ( $pos >= scalar(@otherDeviceCodes) ) {
		# invalid position
                $client->bumpRight($client);
		$client->lines(\&lines);
		$client->update();
		return;
	}
	my $device = $otherDeviceCodes[$pos];
	my $deviceName = $otherDeviceNames[$pos];
	$deviceName =~ s/\(\+\)//;
	my $line1 = string('PLUGIN_POWERCENTER');
	if (! defined($line2) ) {
		my $showPos = '';
		if ( $pos < 8 ) {
			$showPos = ' #'.($pos + 1);
		}
		$line2 = "X-10${showPos}: $powerName $deviceName ($device)";
	}
	$client->showBriefly( { 'line' => [$line1,$line2]},{'duration' => 1, 'block' => 1, } );
#, 1, 0, 1);
	$log->debug("power $powerArg $powerName for $id other $pos dev $device\n");
	&sendX10Code($device,$powerArg,$dimArg,$id);
	$client->lines(\&lines);
	$client->update();
	$now  = Time::HiRes::time();
	$lastActionTime{$id} = $now;
	$lastActionArgs{$id} = $argString;
}

sub advanceCursor($$) {
	my ($client, $incr) = @_;
	my $pos = $prefs->client($client)->get('other-cursor');
	if (! defined($pos) ) {
		$pos = $THIS_DEVICE_POS;
	}
	$pos += $incr;
	# wrap around if 'up'
	if ($pos < $minCursorValue) {
		# note, with 0 devices, the following gives -1, which should be $THIS_DEVICE_POS
		$pos = scalar(@otherDeviceCodes) -1;
	}
	# wrap around if 'down'
	if ( $pos >= scalar(@otherDeviceCodes) ) {
		$pos = $minCursorValue;
	}
	$prefs->client($client)->set('other-cursor',$pos);
	return $pos;	
}

sub allDevicesLine() {
	return("X-10: all devices (".join(',',@otherDeviceCodes).")");
}

sub allLightsLine($) {
	my $action = shift;
	my @codes;
	foreach my $houseCode (sort keys %allHouseCodes) {
		push @codes, $houseCode;
	}
	return("X-10: all ".join(',',@otherLampDevices,@codes)." lights $action");
}

sub allLights($$) {
	my ($client,$action) = @_;
	my $id = $client->id();
	my $powerArg = '-B';	# "on"
	my $singlePowerArg = '-n';
	if ( $action eq 'off' ) { 
		$powerArg = '-D'; 
		$singlePowerArg = '-f';
	}
	my @codes;
	foreach my $houseCode (sort keys %allHouseCodes) {
		push @codes, $houseCode;
	}
	my $line = string('PLUGIN_POWERCENTER');
	$client->showBriefly({ 'line' => [$line, &allLightsLine($action)]}, {'duration' => 1, 'block' => 1,} );
#, 1, 0, 1);
	foreach my $code ( @otherLampDevices ) {
		$log->debug("turning $action lamp device $code\n");
		&sendX10Code($code,$singlePowerArg,undef,$id);
	}
	foreach my $houseCode (@codes) {
		$log->debug("turning $action lights for house code $houseCode\n");
		&sendX10Code($houseCode,$powerArg,undef,$id);
	}
}

# sub to run from Slim::Utils::Scheduler to reduce blocking
sub processCommandFromQueue() {
	if ( scalar(@commandQueue) > 0 ) {
		my $cmdPtr = shift @commandQueue;
		my @cmdArgs = @{$cmdPtr};
		my $id = pop @cmdArgs;
		if ( $cmdArgs[0] eq '_INSTEON' ) {
			sendSingleInsteon($id, $cmdArgs[1]);
		} else {
			# X-10/BR
			&brRunCommand($id, \@cmdArgs);
		}
	}
	# return 1 if there are more items to process
	if ( scalar(@commandQueue) > 0 ) {
		return 1;
	}
	# indicate that we're done with the queue
	return 0;
}

sub brRunCommand {
	my ($id, $cmdArgsPtr) = @_;
	my @cmdArgs = @{$cmdArgsPtr};
	my $rc;
	if ($^O !~ /Win32/) {
		# Unix/Linux
		$log->debug("for ID $id, executing command: \"".join(' ',@cmdArgs)."\"\n");
		$rc = system(@cmdArgs);
	} else {
		# Win32
		# thanks to nadams on the Slim Devices forums
		# format the arguments as a string with a 8.3 path from the program
		$cmdArgs[0] = Win32::GetShortPathName($cmdArgs[0]);
		my $cmdstr= join(' ',@cmdArgs);
		$log->debug("for ID $id, executing command: \"$cmdstr\"\n");
		# start a windows process, and wait up to 5 seconds for it to exit
		my $proc = 0;
		$rc = Win32::Process::Create($proc, $cmdArgs[0], $cmdstr, 0, CREATE_NO_WINDOW, ".");
		$proc->Wait(5000);
	}
	$log->debug("for ID $id, return code= \"$rc\"\n");
	return $rc;
}


# sub to add a command to the queue
sub addToQueue {
	# get command args
	my @cmdArgs = @_;
	# add to queue
	push @commandQueue, \@cmdArgs;
	# if nothing was in queue, tell scheduler we need to process the queue
	if ( scalar(@commandQueue) == 1) {
		Slim::Utils::Scheduler::add_task(\&processCommandFromQueue);
	}
}

sub rewriteX10Command($$) {
	my ($cmd,$args) = @_;
	my @argArray;
	if ( $cmd =~ m/\bheyu(|\.exe)$/i ) {
		# discard -x port (in the heyu config file) and -r repeatCount (not used)
		$args =~ s/\s*\-x .* \-r \d* //;
		# get the house code
		$args =~ s/^\s*\-c\s*(\w)//;
		my $house = $1;
		my $heyuArgs = '';
		if ( $args =~ m/-n (\d*)/ ) {
			$heyuArgs = "on ${house}${1}";
			#  heyu  on  HU                     Turn units ON
			#  br -x /dev/null -r 3 -c B -n 2
		} elsif ( $args =~ m/\-f (\d*)/ ) {
			$heyuArgs = "off ${house}${1}";
			#  heyu  off  HU                    Turn units OFF
			#  br -x /dev/null -r 3 -c B -f 2
		} elsif ( $args =~ m/\-d \-([0-9]*),([0-9]*)/ ) {
			$heyuArgs = "dim ${house}${2} ${1}";
			#  heyu  dim  HU <level>            Dim units by <level> (1-22)
			#  br -x /dev/null -r 1 -c A -d -2,1
		} elsif ( $args =~ m/\-d ([0-9]*),([0-9]*)/ ) {
			$heyuArgs = "bright ${house}${2} ${1}";
			#  heyu  bright  HU <level>         Brighten units by <level> (1-22)
			#  br -x /dev/null -r 1 -c A -d 2,1
		} elsif ( $args =~ m/\-B/ ) {
			$heyuArgs = "lightson ${house}";
			#  heyu  lightson  H                Turn All Lights ON
			#  br -x /dev/null -r 3 -c A -B
		} elsif ( $args =~ m/\-D/ ) {
			$heyuArgs = "lightsoff ${house}";
			#  heyu  lightsoff  H               Turn All Lights OFF (**)
			#  br -x /dev/null -r 3 -c A -D
		} elsif ( $args =~ m/\-N/ ) {
			$heyuArgs = "allon ${house}";
			#  heyu  allon  H                   Turn Units 1-16 ON
			#  br -x /dev/null -r 3 -c A -N
		} elsif ( $args =~ m/\-F/ ) {
			$heyuArgs = "alloff ${house}";
			#  heyu  alloff  H                  Turn All Units OFF
			#  br -x /dev/null -r 3 -c A -F
		}
		if ( $heyuArgs eq '' ) { $log->error("Unable to translate br args \"$args\" for heyu!"); }
		my $ourBinDirPrefix = catdir(&findOurDir(),'bin');
		@argArray = split(/ /,$heyuArgs);
		if ($^O =~ m/Win32/) {
			$ourBinDirPrefix = Win32::GetShortPathName($ourBinDirPrefix);
		}
		if ( substr($cmd,0,length($ourBinDirPrefix)) eq $ourBinDirPrefix ) {
			# add -c configFile
			unshift @argArray, "-c",&heyuConfigFileName();
		}
		$log->debug("Convert br args \"$args\" to heyu args \"".join(" ",@argArray)."\"\n");
		# make sure the heyu config file is up to date
		&writeHeyuConfig();
		return @argArray;
	}
	@argArray = split(/ /,$args);
	return @argArray;
}

sub workdirFileName() {
	my $filename = catdir(preferences('server')->get('cachedir'),'PowerCenter');
	if ($^O =~ m/Win32/) {
		$filename = Win32::GetShortPathName($filename);
	}
	mkdir $filename, 0775;
	return $filename;
}

sub heyuConfigFileName() {
	my $filename = catdir(&workdirFileName(),'heyu.x10config');
	if ($^O =~ m/Win32/) {
		return Win32::GetShortPathName($filename);
	}
	return $filename;
}

sub writeHeyuConfig() {
	my $cmd = &getCommand();
	if ( $cmd =~ m/\bheyu(|\.exe)$/i ) {
		my $port = &getPort();	# heyu.exe seems to prefer "COM1", so do *not* use portTransform()
		# do nothing if we've already written this file
		if ( defined($heyuPort) && ($heyuPort eq $port) ) { return; }
		my $templateFilename = catdir(&findOurDir(),'bin','x10config.template');
		if ( open(TEMPLATE,"<$templateFilename") ) {
			my $content = "# config file for 'heyu' for PowerCenter -- based on ${templateFilename}\n";
			while (my $line = <TEMPLATE> ) {
				# replace the TTY entry
				$line =~ s/^\s*TTY\s{1,}BR_PORT_HERE\b.*?([\r\n]*)$/TTY $port $1/;
				# replace the LOCK_DIR/SPOOL_DIR entries
				my $cachedir = &workdirFileName();
				$line =~ s/^\s*((LOCK|SPOOL)_DIR)\s{1,}BR_DIR_HERE\b.*?([\r\n]*)$/$1 "$cachedir"$3/;
				$content .= $line;
			}
			close TEMPLATE;
			if ( open(CONFIG,">".&heyuConfigFileName()) ) {
				print CONFIG $content;
				close CONFIG;
				$heyuPort = $port;
			}
		}
	}
}

sub sendX10Code($$$$) {
	my ($x10Code,$powerArg,$dimArg,$id) = @_;

	my $houseCode = $x10Code;
	my $number = '';
	if ( $x10Code =~ m/^([a-z])([0-9]*)$/i ) { #X10
		($houseCode,$number) = ($1,$2);

		my $cmd = &getCommand();
		my $port = &portTransform(&getPort());
		my $resend = &getResend();
		# don't resend dim requests
		if ( defined($dimArg) ) { $resend = 1; }
		else { $dimArg = ''; }
		my @cmdArgs = ( $cmd );
		push @cmdArgs, &rewriteX10Command($cmd,"-x ${port} -r ${resend} -c ${houseCode} ${powerArg} ${dimArg}${number}");
		#'/usr/local/bin/br','-x','/dev/ttyS0','-r','3' );
		# add command to queue
		push @cmdArgs, $id;
		&addToQueue(@cmdArgs);
	}
	elsif ($x10Code =~ m/^(.+.+\..+.+\..+.+)/i) { #Insteon
		my $command;
		if ($powerArg eq '-n') {
			$command = "SetOnLevelText=$houseCode,ON";
		}
		elsif ($powerArg eq '-f') {
			$command = "SetOnLevelText=$houseCode,OFF";
		}
		elsif ($dimArg == 1) {
			if ($x10Code =~ m/^(.+.+)\.(.+.+)\.(.+.+)/i) {
				$command = "sendINSTEONraw=$plc $1 $2 $3 0F 15";
			}
		}
		elsif ($dimArg == -1) {
			if ($x10Code =~ m/^(.+.+)\.(.+.+)\.(.+.+)/i) {
				$command = "sendINSTEONraw=$plc $1 $2 $3 0F 16";
			}
		}
		&addToQueue('_INSTEON', $command, $id);
	}
}

sub sendSingleInsteon {  #Set up Async HTTP request
	my ($id,$command) = @_;
	$log->debug("Insteon \"$command\" for $id\n");

	my $url = "http://".&getHost()."/yo.txt?$command";
	my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotSingleInsteon,
							  \&gotErrorViaHTTP,
							  {caller => 'sendSingleInsteon',
							   callerProc => \&sendSingleInsteon,
							   id => $id,
							   command => $command});
	$log->debug("Async request: $url\n");
	$http->get($url);
}

sub gotSingleInsteon {  #Response data received
	my $http = shift;
	
	my $params = $http->params();
	my $command = $params->{'command'};

	$log->debug('Got '. $http->url() . "\n");

	my $content = $http->content();
	my @ary=split /\n/,$content; #break large string into array
      	
	#No need to look at response for now...
}

sub gotErrorViaHTTP {
	my $http = shift;
	my $params = $http->params();
	my $caller = $params->{'caller'};
	my $callerProc = $params->{'callerProc'};
	my $command = $params->{'command'};
	my $id = $params->{'id'};

	$log->debug("Error getting ". $http->url() . "\n");
	$log->debug($http->error() . "\n");
	$errorCount++;

	if ($errorCount >3) {
		$log->info("Network error count reached during $caller\n");
	}
	elsif (defined $callerProc) {
		$log->info("Trying $caller again.\n");
		$callerProc->($id,$command);
	}
}

sub sendAll($) {
	my $client = shift;
	my $id = $client->id();
	my $powerName = 'ON';
	if (! defined($powerToggle{$id}) ) {
		$powerToggle{$id} = 0;
	}
	my $toggle = $powerToggle{$id};
	if ( $powerToggle{$id} == 1 ) {
		$powerName = 'OFF';
	}
	my $line2 = "X-10: ${powerName} all (".join(',',@otherDeviceCodes).")";
	for (my $i = 0; $i < scalar(@otherDeviceCodes); ++$i) {
		$powerToggle{$id} = $toggle;
		&deviceAction($i,$client,'-n',$powerName,undef,$line2);
	}
}

sub powerToggle($) {
	my $client = shift;
	my $id = $client->id();
	if (! defined($powerToggle{$id}) ) {
		$powerToggle{$id} = 0;
	}
	$powerToggle{$id} = ( $powerToggle{$id} + 1 ) % 2;
	if ( scalar(@otherDeviceCodes) < 1 ) { 
		$powerToggle{$id} = 0;
	}
	$client->lines(\&lines);
	$client->update();
}

our %configFunctions = (
	# normal up/right/left/down navigation:
		'up' => sub  {
			my $client = shift;
			# this from NetHealth prevents too-fast JVC scrolling
			my $button = shift;
			if ( $button ne 'up' ) { return; }
			# do nothing if in power toggle mode
			my $id = $client->id();
			if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
			&advanceCursor($client, -1);
			# update display
			$client->lines(\&lines);
			$client->update();
		},
		'down' => sub  {
			my $client = shift;
			# this from NetHealth prevents too-fast JVC scrolling
			my $button = shift;
			if ( $button ne 'down' ) { return; }
			# do nothing if in power toggle mode
			my $id = $client->id();
			if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
			&advanceCursor($client, 1);
			# update display
			$client->lines(\&lines);
			$client->update();
		},
		'left' => sub  {
			my $client = shift;
			Slim::Buttons::Common::popModeRight($client);
		},
		'right' => sub  {
			my $client = shift;
			#my $selection = $client->param('listIndex');

			my $pos = &advanceCursor($client,0);
			if (($pos >= 0) & ($otherDeviceCodes[$pos] =~ m/^..\...\...*$/i)) {
				setInsteonMode($client, 'push');
			}
			else {
				$client->bumpRight($client);
			}
		},
	# X-10 functions:
	# play = "on"
        'play' => sub  {
                my $client = shift;
		# do nothing if in power toggle mode
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-n','ON',undef,undef,undef);
        },
        'play_repeat' => sub  {
                my $client = shift;
		# do nothing if in power toggle mode
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-n','ON',undef,undef,undef);
        },
	# pause = "off"
        'pause' => sub  {
		my $client = shift;
		# do nothing if in power toggle mode
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-f','OFF',undef,undef,undef);
        },
        'pause_repeat' => sub  {
		my $client = shift;
		# do nothing if in power toggle mode
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-f','OFF',undef,undef,undef);
        },
	# forward = brighten
        'jump_fwd' => sub  {
                my $client = shift;
		# do nothing if in power toggle mode
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-d','BRIGHT','1,',undef,undef);
        },
        'fwd_repeat' => sub  {
		# do nothing if in power toggle mode
                my $client = shift;
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-d','BRIGHT','1,',undef,undef);
        },
	# rewind = dim
        'jump_rew' => sub  {
		my $client = shift;
		# do nothing if in power toggle mode
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-d','DIM','-1,',undef,undef);
        },
        'rew_repeat' => sub  {
		my $client = shift;
		# do nothing if in power toggle mode
		my $id = $client->id();
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		&sendCode($client,'-d','DIM','-1,',undef,undef);
        },
        'scan_fwd' => sub  {
                my $client = shift;
		# do nothing (prevent affecting playback)
	},
        'scan_rew' => sub  {
		my $client = shift;
		# do nothing (prevent affecting playback)
	},
	# press "add" briefly -- all lights on
	'add' => sub {
		my $client = shift;
		my $id = $client->id();
		# comment the following out to disable Sleep + Add == all lights off
		#if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) {
			&allLights($client,"off");
			$powerToggle{$id} = 0;
		} else {
			&allLights($client,"on");
		}
		$client->lines(\&lines);
		$client->update();
	},
	# hold "add" -- all lights off
	'add_repeat' => sub {
		# No, not really. Comment out the following is you really want this...
		return;
		my $client = shift;
		my $id = $client->id();
		# comment the following out to disable Sleep + Add == all lights off
		#if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) { return; }
		if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) {
			&allLights($client,"off");
			$powerToggle{$id} = 0;
		} else {
			&allLights($client,"on");
		}
		$client->lines(\&lines);
		$client->update();
	},
	'search' => sub {
		my $client = shift;
		&powerToggle($client);
	},
	'sleep' => sub {
		my $client = shift;
		&powerToggle($client);
	},
	# numbers
	# 0 == act on the first 9 devices
	'numberScroll_0' => sub {
		my $client = shift;
		&sendAll($client);
	},
	# 1 - 9 : act on only the single device
	'numberScroll_1' => sub {
		my $client = shift;
		&deviceAction(0,$client,'-n','ON',undef,undef);
	},
	'numberScroll_2' => sub {
		my $client = shift;
		&deviceAction(1,$client,'-n','ON',undef,undef);
	},
	'numberScroll_3' => sub {
		my $client = shift;
		&deviceAction(2,$client,'-n','ON',undef,undef);
	},
	'numberScroll_4' => sub {
		my $client = shift;
		&deviceAction(3,$client,'-n','ON',undef,undef);
	},
	'numberScroll_5' => sub {
		my $client = shift;
		&deviceAction(4,$client,'-n','ON',undef,undef);
	},
	'numberScroll_6' => sub {
		my $client = shift;
		&deviceAction(5,$client,'-n','ON',undef,undef);
	},
	'numberScroll_7' => sub {
		my $client = shift;
		&deviceAction(6,$client,'-n','ON',undef,undef);
	},
	'numberScroll_8' => sub {
		my $client = shift;
		&deviceAction(7,$client,'-n','ON',undef,undef);
	},
	'numberScroll_9' => sub {
		my $client = shift;
		&deviceAction(8,$client,'-n','ON',undef,undef);
	},
	'playFavorite_1' => sub {},
	'playFavorite_2' => sub {},
	'playFavorite_3' => sub {},
	'playFavorite_4' => sub {},
	'playFavorite_5' => sub {},
	'playFavorite_6' => sub {},
	'playFavorite_7' => sub {},
	'playFavorite_8' => sub {},
	'playFavorite_9' => sub {},
	'playFavorite_0' => sub {},
);

sub setInsteonMode() {
	my $client = shift;
	my $method = shift;
	
	if ($method eq 'pop') {
		Slim::Buttons::Common::popMode($client);
		return;
	}
	
	$current{$client} ||= 0;

	my @insteonMenu = ("0%", "10%", "20%", "30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%");

	my $pos = &advanceCursor($client,0);
	my %params = (
		header => $otherDeviceNames[$pos],
		listRef => \@insteonMenu,
		externRef => sub {
			my $client = shift;
			my $value = shift;

			return $value;
		},
		headerAddCount => 1,
		overlayRef => sub {return (undef, $client->symbols('rightarrow'));},
		valueRef => \$current{$client},
		callback => sub {
			my $client = shift;
			my $method = shift;

			if ($method eq 'left') {
				Slim::Buttons::Common::popModeRight($client);
				return;
			}
			
			if ($client->param('listIndex')<11) {
				my $pos = &advanceCursor($client,0);
				
				$client->showBriefly($otherDeviceNames[$pos] ."\n");
				&addToQueue('_INSTEON', 'SetOnLevelText=' . $otherDeviceCodes[$pos] . ',' . $client->param('listIndex')*10 . "%25", $client->id());
			}
		},
	);

	Slim::Buttons::Common::pushModeLeft($client, 'INPUT.List', \%params);
}

sub lines {
	my $client = shift;
	my $id = $client->id();
	my ($line1, $line2);
	$line1 = string('PLUGIN_POWERCENTER');
	my $pos = &advanceCursor($client,0);
	if ( defined($powerToggle{$id}) && ($powerToggle{$id} == 1) ) {
		# special mode
		my $max = scalar(@otherDeviceCodes);
		$max =  ($max > 9) ? 9 : $max;
		$line2 = string('PLUGIN_POWERCENTER_POWER_TOGGLE');
		$line2 =~ s/MAXVALUE/$max/e;
	}
	elsif ( $pos == $THIS_DEVICE_POS) {
		my $x10Code = $prefs->client($client)->get('code');
		if ( defined($x10Code) && ($x10Code =~ m/^[a-z][0-9]*$/i) ) {
			$line2 = string('PLUGIN_POWERCENTER_MANAGED')." X-10 code ${x10Code}.";
		}
		elsif ( defined($x10Code) && ($x10Code =~ m/^..\...\...*$/i) ) {
			$line2 = string('PLUGIN_POWERCENTER_MANAGED')." Insteon ID ${x10Code}.";

		} else {
			$line2 = string('PLUGIN_POWERCENTER_UNMANAGED');
		}
	}
	elsif ( $pos == $ALL_LIGHTS_POS ) {
		$line2 = &allLightsLine('');
	}
	elsif ( $pos == $ALL_DEVICES_POS ) {
		$line2 = &allDevicesLine();
	}
	else {
		my $showPos = '';
		if ( $pos < 8 ) {
			$showPos = ' #'.($pos + 1);
		}
		my $deviceName = $otherDeviceNames[$pos];
		$deviceName =~ s/\(\+\)//;
		$line2 = $showPos.': '.$deviceName;
	}
	return ( { 'line' => [$line1, $line2] } );
}

sub getFunctions {
	return \%configFunctions;
}

sub setMode {
	my $client = shift;
	$client->lines(\&lines);
}

sub loadOtherArrays() {
	my $others = &getOthers();
	if (!defined($others)) { return; }
	$log->debug("others \"$others\"\n");
	my @pairs = split(/\;/, $others);
	my $pos = 0;
	@otherDeviceCodes = ();
	@otherDeviceNames = ();
	%allHouseCodes = ();
	@otherLampDevices = ();
	$minCursorValue = $THIS_DEVICE_POS;
	foreach my $pair ( @pairs ) {
		if ( $pair =~ m/^\s*([a-p][0-9]{1,2})\s*\=\s*(\S{1,}.*?)\s*$/i ) { #X10
			my ($device,$name) = ($1, $2);
			$device = uc($device);
			push @otherDeviceCodes, $device;
			push @otherDeviceNames, $name;
			my $house = substr($device,0,1);
			$allHouseCodes{$house} = 1;
			my $showPos = $pos + 1;
			$log->debug("X10 device $pos (visible as \#${showPos}) has code $device and is named \"$name\"\n");
			if ( $name =~ m/\+/ ) {
				$log->debug("X10 device $pos has a plus in its name (\"$name\") and will be treated as a light\n");
				push @otherLampDevices, $device;
			}
			++$pos;
		}
		elsif ( $pair =~ m/^\s*(.+.+\..+.+\..+.+)\s*\=\s*(\S{1,}.*?)\s*$/i ) { #Insteon
			my ($device,$name) = ($1, $2);
			$device = uc($device);
			push @otherDeviceCodes, $device;
			push @otherDeviceNames, $name;
			my $house = substr($device,0,1);
			# allHouseCodes is only used for X-10 devices,
			# for the "all devices" action
			#$allHouseCodes{$house} = 1;
			my $showPos = $pos + 1;
			$log->debug("Insteon device $pos (visible as \#${showPos}) has code $device and is named \"$name\"\n");
			if ( $name =~ m/\+/ ) {
				$log->debug("Insteon device $pos has a plus in its name (\"$name\") and will be treated as a light\n");
				push @otherLampDevices, $device;
			}
			++$pos;
		}
		
	}
	if ( scalar(@otherDeviceCodes) > 0 ) {
		$minCursorValue = $ALL_LIGHTS_POS;
	}
}

# web settings routines

# setAll() -- 	set per-player config values for global settings to be the
# 		same on each player
sub setAll() {
        my @players = Slim::Player::Client::clients();
        for my $player (@players) {
		foreach my $name ('brcommand','port','resend','others','dmhost') {
			my $prefname = "${name}";
			my $value = $prefs->get($prefname);
			$prefs->client($player)->set($prefname,$value);
		}
	}
}

# function to ensure user-entered X-10 code is OK
sub validateCode {
	my $code = shift;
	# empty string == disable
	if ( $code =~ /^(disabled|)\s*$/ ) {
		return "disabled";
	}
	elsif ( $code =~ m/^([a-p])([0-9]{1,2})$/i ) {
		my ($house,$num) = ($1,$2);

		if ( ($num < 1) || ($num > 16) ) {
			# return false
			return undef;
		}
		else {
			# return canonical string
			return uc("${house}${num}");
		}
	}
	elsif ($code =~ m/^\s*(.+.+\..+.+\..+.+)$/i) {
		return uc($1);
	}
	else {
		return undef;
	}
}

# function to ensure user-supplied 'br' path is OK
sub validateCommand {
	my $cmd = shift;
	# do not complain if no change
	if ( $cmd eq &getCommand() ) { return $cmd; }
	if ( (! -f $cmd) && (! -x $cmd) ) {
		# not usable
		return undef;
	}
	$prefs->set('brcommand',$cmd);
	&setAll();
	return $cmd;
}

# function to ensure user-supplied serial port device is OK
sub validatePort {
	my $port = shift;
	# do not complain if no change
	if ( $port eq &getPort() ) { return $port; }
	if ( ! -w $port ) {
		# not usable
		return undef;
	}
	$prefs->set('port',$port);
	&setAll();
	return $port;
}

# function to ensure user-supplied resend count is OK
sub validateResend {
	my $resend = shift;
	if ( $resend !~ m/^[1-9]$/ ) {
		# not usable
		return undef;
	}
	$prefs->set('port',$port);
	$prefs->set('resend',$resend);
	&setAll();
	return $resend;
}

# function to ensure user-supplied list of other devices is OK
sub validateOthers {
	my $others = shift;
	# do not complain if no change
	if ( $others eq &getOthers() ) { return $others; }
	my @pairs = split(/\;/, $others);
	my $newString = '';
	foreach my $pair ( @pairs ) {
		if ( $pair =~ m/^\s*([a-p][0-9]{1,2})\s*\=\s*(\S{1,}.*?)\s*$/i ) {
			my ($device,$name) = ($1, $2);
			$newString .= uc(${device})."=${name};";				
		}
		elsif ($pair =~ m/^\s*(.+.+\..+.+\..+.+)\s*\=\s*(\S{1,}.*?)\s*$/i) {
			my ($device,$name) = ($1, $2);
			$newString .= uc(${device})."=${name};";		
		}
		else {
				# badly formatted pair
				return undef;			
		}		
	}
	$newString =~ s/\;$//;
	$prefs->set('others',$newString);
	&setAll();
	# reload the others arrays
	&loadOtherArrays();
	return $newString;
}

# function to validate/globalize Insteon hostname
sub validateDmhost {
	my $host = shift;
	# do not complain if no change
	if ( $host eq &getHost() ) { return $host; }
	# validate as host, host:port, IP, or IP:port?
	$prefs->set('dmhost',$host);
	&setAll();
	return $host;
}


# get global value for default for each player settings page
sub getCommand {
	return $prefs->get('brcommand');
}
sub getPort {
	return $prefs->get('port');
}
sub getResend {
	return $prefs->get('resend');
}
sub getOthers {
	return $prefs->get('others');
}
sub getHost {
	return $prefs->get('dmhost');
}

# required function to indicate what settings to offer in the web UI
sub setupGroup {
	my $client = shift;
   
	my %setupGroup = (
		PrefOrder => ['X10-code','br-command','br-port','br-resend','br-others','dmhost'],
			,GroupHead => Slim::Utils::Strings::string('SETUP_GROUP_PLUGIN_POWERCENTER')
			,GroupDesc => Slim::Utils::Strings::string('SETUP_GROUP_PLUGIN_POWERCENTER_DESC')
			,GroupLine => 1
			,GroupSub => 1
			,Suppress_PrefSub => 1
			,Suppress_PrefLine => 1
			,Suppress_PrefHead => 0
			,Suppress_PrefDesc => 0
	);

	my %setupPrefs = (
		'X10-code' => {
			'validate' => \&Plugins::PowerCenter::Plugin::validateCode
			,PrefName => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-X10-CODE')
			,PrefDesc => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-X10-CODE_DESC')
		},
		'br-command' => {
			'validate' => \&Plugins::PowerCenter::Plugin::validateCommand
			,currentValue => \&Plugins::PowerCenter::Plugin::getCommand
			,PrefSize => 'large'
			,PrefName => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-COMMAND')
			,PrefDesc => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-COMMAND_DESC')
		},
		'br-port' => {
			'validate' => \&Plugins::PowerCenter::Plugin::validatePort
			,currentValue => \&Plugins::PowerCenter::Plugin::getPort
			,PrefSize => 'large'
			,PrefName => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-PORT')
			,PrefDesc => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-PORT_DESC')
		},
		'br-resend' => {
			'validate' => \&Plugins::PowerCenter::Plugin::validateResend
			,currentValue => \&Plugins::PowerCenter::Plugin::getResend
			,PrefName => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-RESEND')
			,PrefDesc => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-RESEND_DESC')
		},
		'br-others' => {
			'validate' => \&Plugins::PowerCenter::Plugin::validateOthers
			,currentValue => \&Plugins::PowerCenter::Plugin::getOthers
			,PrefSize => 'large'
			,PrefName => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-OTHERS')
			,PrefDesc => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-BR-OTHERS_DESC')
		},
		'dmhost' => {
			'validate' => \&Plugins::PowerCenter::Plugin::validateDmhost
			,currentValue => \&Plugins::PowerCenter::Plugin::getHost
			,PrefSize => 'large'
			,PrefName => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-DMHOST')
			,PrefDesc => Slim::Utils::Strings::string('SETUP_PLUGIN-POWERCENTER-DMHOST_DESC')
		},
	);	

	# the final "1" arg says to put this in the player prefs   
	return (\%setupGroup,\%setupPrefs,1);
}

# Coffee maker
sub alarmSoundHandler {
	my $request = shift;
	my $client = $request->client();
	if (!defined($client)) {
		$log->error("alarm sounded but we cannot determine for which player!");
		return;
	}
	my $cname = $client->name();
	$log->debug("alarm sounded for client \"$cname\"");
	# check this player's prefs
	my $x10Code = $prefs->client($client)->get('coffeepot');
	# if coffeemaker device set
	if ( defined($x10Code) && ($x10Code !~ m/^(disabled|)$/) ) {
		$log->info("turning on coffee pot for client \"$cname\"");
		# send on code twice
		&turnOnCoffeeMaker($client,$x10Code);
		# set timer to send off code
		my $delay = $prefs->client($client)->get('coffeedelay');
		Slim::Utils::Timers::setTimer($client, time() + ($delay * 60), \&turnOffCoffeeMaker, $x10Code)
	}
}

sub turnOnCoffeeMaker {
	my $client = shift;
	my $dev = shift;
	if (! defined($coffeepotsInUse{$dev}) ) { $coffeepotsInUse{$dev} = 0; }
	++$coffeepotsInUse{$dev};
	# send on code three times
	for (my $i = 0; $i < 3; ++$i) {
		&sendX10Code($dev,'-n',undef,$client->id());
	}
}

sub turnOffCoffeeMaker {
	my $client = shift;
	my $dev = shift;
	my $cname = $client->name();
	$log->info("turning OFF coffee pot for client \"$cname\"");
	# send off code three times
	for (my $i = 0; $i < 3; ++$i) {
		&sendX10Code($dev,'-f',undef,$client->id());
	}
	--$coffeepotsInUse{$dev};
}

sub makesCoffee {
	return $canMakeCoffee;
}

1;

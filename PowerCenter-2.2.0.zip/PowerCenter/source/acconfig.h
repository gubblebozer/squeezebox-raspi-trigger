/*
 * Do we have getopt_long() ?
 */
#undef HAVE_GETOPT_LONG

/*
 * How about issetugid() ?
 */
#undef HAVE_ISSETUGID

/*
 * Do we want debugging?
 */
#undef DEBUG


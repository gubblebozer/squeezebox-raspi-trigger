package Plugins::PowerCenter::PlayerSettings;

# PowerCenter Copyright (c) 2006-2008 Peter Watkins
#
# SqueezeCenter Copyright (c) 2001-2007 Logitech.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::DateTime;

my $prefs = preferences('plugin.PowerCenter');
my @prefNames = ('code','coffeepot','coffeedelay');

sub needsClient {
	return 1;
}

$prefs->migrateClient(1, sub {
	my ($clientprefs, $client) = @_;
	# convert old pref
	$clientprefs->set('code', Slim::Utils::Prefs::OldPrefs->clientGet($client, 'plugin-PowerCenter-X10-code'));
	1;
});

sub name {
	if ( substr($::VERSION,0,3) lt 7.4 ) {
		return Slim::Web::HTTP::protectName('PLUGIN_POWERCENTER_PLAYER_SETTINGS');
	}
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_POWERCENTER_PLAYER_SETTINGS');
}

sub page {
	if ( substr($::VERSION,0,3) lt 7.4 ) {
		return Slim::Web::HTTP::protectURI('plugins/PowerCenter/settings/player.html');
	}
	return Slim::Web::HTTP::CSRF->protectURI('plugins/PowerCenter/settings/player.html');
}

sub prefs {
	my ($class,$client) = @_;
	return ($prefs->client($client), @prefNames );
}

sub handler {
	my ($class, $client, $params) = @_;
	my $delay = $prefs->client($client)->get('coffeedelay');
	my $pot = $prefs->client($client)->get('coffeepot');
	if ( (!defined($delay)) ||
	     ($delay eq '') ) {
		$prefs->client($client)->set('coffeedelay',30);
	}
	if ( (!defined($pot)) ) {
		$prefs->client($client)->set('coffeepot','');
	}
	# for bug 6873/change 19155
	if ($::VERSION ge '7.1') {
 		$params->{'pw'}->{'pref_prefix'} = 'pref_';
 	} else {
 		$params->{'pw'}->{'pref_prefix'} = '';
 	}
	### BUG -- validate prefs
	$params->{powercenter}->{coffee} =  Plugins::PowerCenter::Plugin::makesCoffee();
	return $class->SUPER::handler($client, $params);
}

sub getPrefs {
	return $prefs;
}

1;

__END__

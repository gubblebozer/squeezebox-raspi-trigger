package Plugins::PowerCenter::Settings;

# PowerCenter Copyright (c) 2006-2008 Peter Watkins
#
# SqueezeCenter Copyright (c) 2001-2007 Logitech.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::DateTime;

my $prefs = preferences('plugin.PowerCenter');
my @prefNames = ('brcommand','port','resend', 'others','dmhost');
my @oldPrefNames = ('br-command','br-port','br-resend', 'br-others','dmhost');

sub needsClient {
	return 0;
}

$prefs->migrate(1, sub {
	my ($class) = @_;
	# convert old pref
	for (my $i = 0; $i < scalar(@oldPrefNames); ++$i ) {
		my $newName = $prefNames[$i];
		my $oldName = $oldPrefNames[$i];
		$prefs->set($newName, Slim::Utils::Prefs::OldPrefs->get('plugin-PowerCenter-'.$oldName));
	}
	1;
});

sub name {
	if ( substr($::VERSION,0,3) lt 7.4 ) {
		return Slim::Web::HTTP::protectName('PLUGIN_POWERCENTER_BASIC_SETTINGS');
	}
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_POWERCENTER_BASIC_SETTINGS');
}

sub page {
	if ( substr($::VERSION,0,3) lt 7.4 ) {
		return Slim::Web::HTTP::protectURI('plugins/PowerCenter/settings/basic.html');
	}
	return Slim::Web::HTTP::CSRF->protectURI('plugins/PowerCenter/settings/basic.html');
}

sub prefs {
	return ($prefs, @prefNames );
}

sub handler {
	my ($class, $client, $params) = @_;
	### BUG - validate prefs!
	# might need new Jive menu
	Slim::Control::Jive::refreshPluginMenus();
        # for bug 6873/change 19155
	if ($::VERSION ge '7.1') {
		$params->{'pw'}->{'pref_prefix'} = 'pref_';
	} else {
		$params->{'pw'}->{'pref_prefix'} = '';
	}
	my $rc = $class->SUPER::handler($client, $params);
	# rewrite heyu config
	Plugins::PowerCenter::Plugin::writeHeyuConfig();
	# rebuild list of others
	Plugins::PowerCenter::Plugin::loadOtherArrays();
	return $rc;
}

sub getPrefs {
	return $prefs;
}

1;

__END__
